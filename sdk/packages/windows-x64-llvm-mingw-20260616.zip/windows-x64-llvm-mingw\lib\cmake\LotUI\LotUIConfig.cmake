
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was LotUIDesktopConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

get_filename_component(_lotui_public_include
    "${PACKAGE_PREFIX_DIR}/../include" ABSOLUTE)
if(NOT EXISTS "${_lotui_public_include}/lotui/lotui.h")
    set(LotUI_FOUND FALSE)
    set(LotUI_NOT_FOUND_MESSAGE
        "LotGUI_Sample requires the shared sdk/include headers beside its platform SDK")
    return()
endif()

include(CMakeFindDependencyMacro)
find_dependency(Vulkan)
if(OFF)
    find_dependency(X11)
endif()

foreach(_lotui_dependency freetype harfbuzz tinyxml2)
    if(NOT TARGET LotUI::${_lotui_dependency})
        add_library(LotUI::${_lotui_dependency} STATIC IMPORTED)
    endif()
    foreach(_lotui_configuration Release Debug RelWithDebInfo MinSizeRel)
        set(_lotui_archive
            "${PACKAGE_PREFIX_DIR}/lib/${_lotui_configuration}/lotui_dep_${_lotui_dependency}.a")
        if(EXISTS "${_lotui_archive}")
            string(TOUPPER "${_lotui_configuration}"
                _lotui_configuration_upper)
            set_property(TARGET LotUI::${_lotui_dependency}
                APPEND PROPERTY IMPORTED_CONFIGURATIONS
                "${_lotui_configuration_upper}")
            set_target_properties(LotUI::${_lotui_dependency} PROPERTIES
                "IMPORTED_LOCATION_${_lotui_configuration_upper}"
                "${_lotui_archive}")
        endif()
    endforeach()
endforeach()

add_library(LotUI::FreeTypeBinary ALIAS LotUI::freetype)
add_library(LotUI::HarfBuzzBinary ALIAS LotUI::harfbuzz)
add_library(LotUI::TinyXmlBinary ALIAS LotUI::tinyxml2)
include("${CMAKE_CURRENT_LIST_DIR}/LotUITargets.cmake")
# The sample owns one shared header tree rather than one copy per triplet.
foreach(_lotui_target
    Core Text Widgets Renderer Platform Vulkan VulkanEmbedded TextFreeType Declarative)
    set_target_properties(LotUI::${_lotui_target} PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${_lotui_public_include}")
endforeach()
check_required_components(LotUI)

if(MINGW)
    find_dependency(Threads)
    set_property(TARGET LotUI::harfbuzz APPEND PROPERTY
        INTERFACE_LINK_LIBRARIES Threads::Threads)
endif()
