#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LotUI::Core" for configuration "Release"
set_property(TARGET LotUI::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_core.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Core )
list(APPEND _cmake_import_check_files_for_LotUI::Core "${_IMPORT_PREFIX}/lib/Release/liblotui_core.a" )

# Import target "LotUI::Text" for configuration "Release"
set_property(TARGET LotUI::Text APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Text PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_text.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Text )
list(APPEND _cmake_import_check_files_for_LotUI::Text "${_IMPORT_PREFIX}/lib/Release/liblotui_text.a" )

# Import target "LotUI::Widgets" for configuration "Release"
set_property(TARGET LotUI::Widgets APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Widgets PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_widgets.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Widgets )
list(APPEND _cmake_import_check_files_for_LotUI::Widgets "${_IMPORT_PREFIX}/lib/Release/liblotui_widgets.a" )

# Import target "LotUI::Renderer" for configuration "Release"
set_property(TARGET LotUI::Renderer APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Renderer PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_renderer.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Renderer )
list(APPEND _cmake_import_check_files_for_LotUI::Renderer "${_IMPORT_PREFIX}/lib/Release/liblotui_renderer.a" )

# Import target "LotUI::Platform" for configuration "Release"
set_property(TARGET LotUI::Platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Platform PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_platform.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Platform )
list(APPEND _cmake_import_check_files_for_LotUI::Platform "${_IMPORT_PREFIX}/lib/Release/liblotui_platform.a" )

# Import target "LotUI::Vulkan" for configuration "Release"
set_property(TARGET LotUI::Vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_vulkan.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Vulkan )
list(APPEND _cmake_import_check_files_for_LotUI::Vulkan "${_IMPORT_PREFIX}/lib/Release/liblotui_vulkan.a" )

# Import target "LotUI::VulkanEmbedded" for configuration "Release"
set_property(TARGET LotUI::VulkanEmbedded APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::VulkanEmbedded PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_vulkan_embedded.a"
  )

list(APPEND _cmake_import_check_targets LotUI::VulkanEmbedded )
list(APPEND _cmake_import_check_files_for_LotUI::VulkanEmbedded "${_IMPORT_PREFIX}/lib/Release/liblotui_vulkan_embedded.a" )

# Import target "LotUI::TextFreeType" for configuration "Release"
set_property(TARGET LotUI::TextFreeType APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::TextFreeType PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_text_freetype.a"
  )

list(APPEND _cmake_import_check_targets LotUI::TextFreeType )
list(APPEND _cmake_import_check_files_for_LotUI::TextFreeType "${_IMPORT_PREFIX}/lib/Release/liblotui_text_freetype.a" )

# Import target "LotUI::Declarative" for configuration "Release"
set_property(TARGET LotUI::Declarative APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LotUI::Declarative PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/Release/liblotui_declarative.a"
  )

list(APPEND _cmake_import_check_targets LotUI::Declarative )
list(APPEND _cmake_import_check_files_for_LotUI::Declarative "${_IMPORT_PREFIX}/lib/Release/liblotui_declarative.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
